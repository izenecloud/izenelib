//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WinGUI.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_WINGUI_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDD_WORKDIALOG                  129
#define IDC_FILLRANDOMBUTTON            1000
#define IDC_FILENAMEEDIT                1001
#define IDC_FILENAMEBUTTON              1002
#define IDC_INTEGERKEYEDIT              1003
#define IDC_FILLVALUEBUTTON             1004
#define IDC_FORMAT1RADIO                1005
#define IDC_FORMAT2RADIO                1006
#define IDC_FILESIZEEDIT                1007
#define IDC_FILESIZEEDIT2               1008
#define IDC_FILESIZEEDITMB              1008
#define IDC_SORTASCBUTTON               1009
#define IDC_MESSAGE1                    1009
#define IDC_SORTDESCBUTTON4             1010
#define IDC_CHECKASCBUTTON              1011
#define IDC_CHECKDESCBUTTON             1012
#define IDC_REMDUPLBUTTON               1013
#define IDC_CHECKDUPLBUTTON             1014
#define IDC_MEMUSAGEEDIT                1015

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
 #ifndef APSTUDIO_READONLY_SYMBOLS
  #define _APS_NEXT_RESOURCE_VALUE        130
  #define _APS_NEXT_COMMAND_VALUE         32771
  #define _APS_NEXT_CONTROL_VALUE         1010
  #define _APS_NEXT_SYMED_VALUE           101
 #endif
#endif
